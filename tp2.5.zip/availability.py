#################################################
# availability.py
#
# Your name: Yee Kit Chan
# Your andrew id: yeekitc
#################################################

import math, os, copy, decimal, datetime
from cmu_112_graphics import *
import module_manager
module_manager.review()

class Availability:
    def __init__(self, times, days):
        pass

    def __repr__(self):
        pass