#################################################
# textBox.py
#
# Your name: Yee Kit Chan
# Your andrew id: yeekitc
#################################################

import math, os, copy, decimal, datetime
from cmu_112_graphics import *
import module_manager
module_manager.review()

class TextBox:
    def __init__(self, x0, y0, x1, y1, outlineC="", selectC=""):
        self.x0 = x0
        self.y0 = y0
        self.x1 = x1
        self.y1 = y1

        # colors
        self.outlineC = "#143936"
        self.selectC = "#9FF8E2"

