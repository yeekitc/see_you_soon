#################################################
# __init__.py
#
# Your name: Yee Kit Chan
# Your andrew id: yeekitc
#################################################

import math, os, copy, decimal, datetime
from cmu_112_graphics import *
from button import *
import module_manager
module_manager.review()

#################################################
# Splash Screen
#################################################

def splashScreenMode_appAttributes(app):
    app.welcText = 'w e l c o m e   t o   s e e_y o u_s o o n'
    app.welcInd = 0
    app.arrY = app.height/2+40
    app.arrDir = 1
    app.welcArrow = app.scaleImage(app.loadImage('rightArrow.png'), 1/3)
    app.arrWidth, app.arrHeight = app.welcArrow.size
    app.slide = False
    app.slideX0 = 0
    app.slideX = 0
    app.slide2X = 0
    app.splashTimer = 0
    app.timerDelay = 1

def splashScreenMode_redrawAll(app, canvas):
    font = 'Open Sans', '40'
    canvas.create_rectangle(0, 0, app.width, app.height, fill=app.bgC)
    canvas.create_text(app.width/2, app.height/2-40, 
        text=app.welcText[:app.welcInd+1], font=font, fill=app.textC)
    if app.welcInd+1 == len(app.welcText):
        # https://icons8.com/icon/39969/right-arrow
        canvas.create_image(app.width/2-app.arrWidth/2, app.arrY, 
                            image=ImageTk.PhotoImage(app.welcArrow))
    if app.slide:
        canvas.create_rectangle(0, 0, app.slide2X, app.height, fill=app.bgC)
        canvas.create_rectangle(app.slideX0, 0, app.slideX, app.height, fill=app.textC)
        
def splashScreenMode_timerFired(app):
    app.splashTimer += 1
    if app.splashTimer%8 == 0:
        if app.arrY <= app.height/2+20 or app.arrY > app.height/2+40:
            app.arrDir *= -1
        app.arrY -= 1*app.arrDir
    if app.welcInd+1 != len(app.welcText) and app.splashTimer%8 == 0:
        app.welcInd += 1
    elif app.slide:
        if app.slideX != app.width:
            app.slideX += 5
            app.slide2X += 5
        elif app.slideX0 != app.width:
            app.slideX0 += 5
        else:
            app.mode = "landingMode"

def splashScreenMode_mousePressed(app, event):
    if app.welcInd+1 == len(app.welcText):
        app.slide = True

def splashScreenMode_keyPressed(app, event):
    if app.welcInd+1 == len(app.welcText):
        app.slide = True

#################################################
# Landing Page
#################################################

def landingMode_appAttributes(app):
    app.matrixIm = app.scaleImage(app.loadImage('matrixPlaceholder.png'), 1)
    app.matrixImWidth, app.matrixImHeight = app.matrixIm.size

def landingMode_redrawAll(app, canvas):
    titleFont = "Open Sans", "40"
    font = "Open Sans", "20"
    drawNav(app, canvas)
    canvas.create_text(app.width/12, app.height/2, text="Welcome to see_you_soon!", 
                    font=titleFont, fill=app.textC, anchor=W)
    canvas.create_text(app.width/12, app.height/2+50, text="lorem ipsum text which will be a succinct description of the app and its function", 
                    font=font, fill=app.textC, width=450, anchor=NW)
    canvas.create_image(app.width*23/24-app.matrixImWidth/2, (app.height-app.navH)/2+app.navH, 
                            image=ImageTk.PhotoImage(app.matrixIm))
    # Button will go here
    # Plan a New Meeting

##########################################
# Sign Up Page
##########################################

def signUpMode_appAttributes(app):
    pass

def signUpMode_redrawAll(app, canvas):
    drawNav(app, canvas)

##########################################
# Sign In Page
##########################################

def signInMode_appAttributes(app):
    pass

def signInMode_redrawAll(app, canvas):
    drawNav(app, canvas)

##########################################
# Event Availability Page (Attendee)
##########################################

def eventAvailMode_appAttributes(app):
    app.availGradient = ["#DCEAEA", "#9FF8E2", "#64EACF", "#28DBBB",
                        "#20B799", "#179376", "#137361", "#0F524C"]

def eventAvailMode_redrawAll(app, canvas):
    drawNav(app, canvas)

def eventAvailMode_mousePressed(app, event):
    pass

def eventAvailMode_mouseReleased(app, event):
    pass

def eventAvailMode_mouseMoved(app, event):
    pass

def eventAvailMode_mouseDragged(app, event):
    pass

##########################################
# Creating Event Page
##########################################

def createEventMode_appAttributes(app):
    pass

def createEventMode_redrawAll(app, canvas):
    pass

##########################################
# Main App
##########################################

def appStarted(app):
    app.font = "Open Sans", "20"
    app.mode = 'splashScreenMode'
    app.score = 0
    app.timerDelay = 50
    # app.makeAnMVCViolation = False
    app.signedIn = False
    app.navH = app.height/10

    # colors
    app.bgC = "#FFFFFF"
    app.textC = "#143936"
    app.accentC = "#20B799"
    app.navC = "#DCEAEA"

    # logo (designed via Canva)
    app.logo = app.scaleImage(app.loadImage('logo.png'), 1/3)
    app.logoWidth, app.logoHeight = app.logo.size

    splashScreenMode_appAttributes(app)
    landingMode_appAttributes(app)
    signUpMode_appAttributes(app)
    signInMode_appAttributes(app)
    eventAvailMode_appAttributes(app)
    createEventMode_appAttributes(app)

def drawNav(app, canvas):
    font = "Open Sans", f"{int(app.navH-50)}"
    canvas.create_rectangle(0, 0, app.width, app.navH, fill=app.navC)
    # canvas.create_image(20+app.logoWidth/2, 20+app.logoHeight/2, image=ImageTk.PhotoImage(app.logo))
    drawLogo(app, canvas, 20, 20, (app.navH-40)*3+20)
    if app.signedIn:
        canvas.create_text(app.width*5/8, app.navH/2, text="Dashboard", font=font, 
                        fill=app.textC, activefill=app.accentC)
    else:
        canvas.create_text(app.width*3/4, app.navH/2, text="Sign In", font=font, 
                        fill=app.textC, activefill=app.accentC)
    # replace with Button ----
    canvas.create_rectangle(app.width*13/16, 20, app.width*31/32, app.navH-20, fill=app.accentC, activefill=app.textC)
    canvas.create_text(app.width*57/64, app.navH/2, text="Plan Meeting", font=font, fill=app.textC, activefill=app.navC)

def drawLogo(app, canvas, x0, y0, x1):
    y1 = y0+(x1-x0)/3
    width, height = x1-x0, y1-y0
    font = "Open Sans", f"{int(height*5/16)}"
    canvas.create_rectangle(x0, y0, x1, y1, fill=app.accentC)
    canvas.create_rectangle(x0+width/35, y0+height*3/35, x1-width/35, y1-height*3/35, fill=app.navC)
    canvas.create_rectangle(x0+width*2/35, y0+height*6/35, x1-width*2/35, y1-height*6/35, fill=app.textC)
    canvas.create_text(x0+width/2, y0+height/2, text="SEE_YOU_SOON", font=font, fill=app.bgC)

runApp(width=1250, height=750)