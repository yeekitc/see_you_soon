#################################################
# button.py
#
# Your name: Yee Kit Chan
# Your andrew id: yeekitc
#################################################

import math, os, copy, decimal, datetime
from cmu_112_graphics import *
import module_manager
module_manager.review()

class Button:
    def __init__(self, x0, y0, x1, y1, text, command, bgC="", activeC="", textC="", activeTextC=""):
        self.x0 = x0
        self.y0 = y0
        self.x1 = x1
        self.y1 = y1
        self.text = text
        self.command = command

        # colors
        self.bgC = bgC
        self.activeC = activeC
        if textC=="":
            self.textC = "#143936"
        else:
            self.textC = textC
        if activeTextC == "":
            self.activeTextC = "#28DBBB"
        else:
            self.activeTextC = activeTextC

    def setBgC(self, bgC):
        self.bgC = bgC

    def setActiveC(self, activeC):
        self.activeC = activeC

    def setCommand(self, command): # where command is a function
        self.command = command

    def onClick(self, event):
        x, y = event.x, event.y
        if x>=self.x0 and x<=self.x1 and y>=self.y0 and y<=self.y1:
            self.command()

    def onHover(self, event):
        # change background color to active color
        # change text color to active text color
        pass

    def drawButton(self, app, canvas):
        width, height = self.x1-self.x0, self.y1-self.y0
        canvas.create_rectangle(self.x0, self.y0, self.x1, self.y1, fill=self.bgC)
        canvas.create_text(width/2, height/2, text=self.text, font=app.font)

class PlanMeeting(Button):
    def __init__(self, x0, y0, x1, y1, text, command):
        super.__init__(self, x0, y0, x1, y1, text, command)

        # colors
        self.bgC = "#28DBBB"
        self.activeC = "#143936"
        self.textC = "#143936"
        self.activeTextC = "#28DBBB"
            